-- Seed data for Nursery Management System
-- Test data with Arabic content

-- Insert default admin user (password: admin123)
INSERT OR IGNORE INTO users (username, password_hash, full_name, role) VALUES 
  ('admin', 'admin123', 'مدير النظام', 'admin'),
  ('teacher1', 'teacher123', 'فاطمة أحمد', 'user'),
  ('manager1', 'manager123', 'سارة محمد', 'manager');

-- Insert sample children
INSERT OR IGNORE INTO children (name, age, parent_name, parent_phone, address, medical_notes, status) VALUES 
  ('محمد أحمد علي', 4, 'أحمد علي', '0551234567', 'حي النزهة، الرياض', 'لا يوجد', 'نشط'),
  ('سلمى عبدالله', 3, 'عبدالله محمد', '0557654321', 'حي الملز، الرياض', 'حساسية من المكسرات', 'نشط'),
  ('يوسف خالد', 5, 'خالد إبراهيم', '0559876543', 'حي العليا، الرياض', 'لا يوجد', 'نشط'),
  ('نور فهد', 2, 'فهد سعد', '0552468135', 'حي السلامة، جدة', 'لا يوجد', 'نشط'),
  ('عبدالرحمن صالح', 6, 'صالح عبدالعزيز', '0558642097', 'حي الروضة، الدمام', 'يحتاج نظارة طبية', 'نشط');

-- Insert sample employees
INSERT OR IGNORE INTO employees (name, position, phone, hire_date, status, salary) VALUES 
  ('فاطمة أحمد', 'مربية', '0551234567', '2023-01-01', 'نشط', 4500.00),
  ('سارة محمد', 'إدارية', '0557654321', '2023-03-15', 'نشط', 5000.00),
  ('نادية خالد', 'مربية مساعدة', '0559876543', '2023-06-01', 'نشط', 3800.00),
  ('هند عبدالله', 'ممرضة', '0552468135', '2023-02-01', 'نشط', 5500.00);

-- Insert sample attendance records for today and recent days
INSERT OR IGNORE INTO attendance (child_id, attendance_date, arrival_time, departure_time, status, notes) VALUES 
  (1, date('now'), '07:30', '15:45', 'حاضر', NULL),
  (2, date('now'), '08:15', '16:00', 'حاضر', 'تأخر في الصباح'),
  (3, date('now'), '07:45', '15:30', 'حاضر', NULL),
  (4, date('now'), '08:00', NULL, 'حاضر', NULL),
  (5, date('now'), NULL, NULL, 'غائب', 'مرض'),
  
  -- Yesterday's attendance
  (1, date('now', '-1 day'), '07:30', '15:45', 'حاضر', NULL),
  (2, date('now', '-1 day'), '08:00', '16:00', 'حاضر', NULL),
  (3, date('now', '-1 day'), '07:45', '15:30', 'حاضر', NULL),
  (4, date('now', '-1 day'), '08:30', '16:15', 'حاضر', 'تأخر قليلاً'),
  (5, date('now', '-1 day'), '08:00', '15:45', 'حاضر', NULL);

-- Insert sample payments
INSERT OR IGNORE INTO payments (child_id, amount, payment_date, payment_type, status, notes) VALUES 
  (1, 800.00, date('now', 'start of month'), 'شهري', 'مدفوع', 'رسوم شهر ' || strftime('%m/%Y', 'now')),
  (2, 800.00, date('now', 'start of month'), 'شهري', 'مدفوع', 'رسوم شهر ' || strftime('%m/%Y', 'now')),
  (3, 800.00, date('now', 'start of month'), 'شهري', 'مدفوع', 'رسوم شهر ' || strftime('%m/%Y', 'now')),
  (4, 800.00, date('now', 'start of month'), 'شهري', 'مستحق', 'رسوم شهر ' || strftime('%m/%Y', 'now')),
  (5, 800.00, date('now', 'start of month'), 'شهري', 'مدفوع', 'رسوم شهر ' || strftime('%m/%Y', 'now'));